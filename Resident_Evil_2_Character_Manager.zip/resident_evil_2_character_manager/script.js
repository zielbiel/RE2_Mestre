const $ = (id) => document.getElementById(id);
const ATTRS = [
  ["for","Força","FOR","Força física e esforço."],
  ["agi","Agilidade","AGI","Esquiva, velocidade e furtividade."],
  ["res","Resistência","RES","Saúde e resistência física."],
  ["int","Intelecto","INT","Investigação e enigmas."],
  ["per","Percepção","PER","Encontrar pistas e detectar perigos."],
  ["con","Controle","CON","Manter a calma diante do terror."]
];
const CLASS_INFO = {
  "Policial": ["Tiro Preciso","+2 em testes com armas de fogo. Equipamento inicial: pistola."],
  "Civil": ["Improviso","+2 em testes de improvisação. Começa com um item extra."],
  "Médico": ["Atendimento Emergencial","+2 em primeiros socorros. Equipamento inicial: kit médico."],
  "Engenheiro": ["Conserto Rápido","+2 em testes mecânicos. Equipamento inicial: ferramentas."],
  "Jornalista": ["Olho Clínico","+2 em investigação. Equipamento inicial: câmera."]
};
let characters = [];
let currentId = null;
let inventory = [];

function uuid(){ return (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()+Math.random())); }
function toast(msg){ const t=$("toast"); t.textContent=msg; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),2200); }
function getStats(){ return Object.fromEntries(ATTRS.map(([key])=>[key,Number(document.querySelector(`[data-attr="${key}"]`).dataset.value)])); }
function buildAttributes(){
  $("attributes").innerHTML = ATTRS.map(([key,name,abbr,desc])=>`
    <div class="attribute">
      <div><b>${name} <span style="color:var(--muted)">(${abbr})</span></b><small>${desc}</small></div>
      <button type="button" class="stepper" data-step="-1" data-key="${key}">−</button>
      <span class="attr-value" id="value-${key}">2</span>
      <button type="button" class="stepper" data-step="1" data-key="${key}">+</button>
    </div>`).join("");
  $("attributes").addEventListener("click", e=>{
    const btn=e.target.closest("[data-step]"); if(!btn)return;
    const el=document.querySelector(`[data-attr="${btn.dataset.key}"]`);
    const next=Number(el.dataset.value)+Number(btn.dataset.step);
    const total=usedAttributePoints();
    if(next<1||next>4||(Number(btn.dataset.step)>0&&total>=6))return;
    el.dataset.value=next; renderAttributes();
  });
  ATTRS.forEach(([key])=>{
    const value=document.createElement("span"); value.hidden=true; value.dataset.attr=key; value.dataset.value=2;
    $("attributes").appendChild(value);
  });
  renderAttributes();
}
function usedAttributePoints(){return ATTRS.reduce((n,[key])=>n+(Number(document.querySelector(`[data-attr="${key}"]`).dataset.value)-1),0);}
function renderAttributes(){
  ATTRS.forEach(([key])=>{$(`value-${key}`).textContent=document.querySelector(`[data-attr="${key}"]`).dataset.value;});
  const used=usedAttributePoints(); $("pointsCount").textContent=`${used} / 6`;
  $("pointsCount").style.color=used===6?"var(--green)":"var(--amber)";
  document.querySelectorAll(".stepper[data-step='1']").forEach(b=>b.disabled=used>=6||Number(document.querySelector(`[data-attr="${b.dataset.key}"]`).dataset.value)>=4);
  document.querySelectorAll(".stepper[data-step='-1']").forEach(b=>b.disabled=Number(document.querySelector(`[data-attr="${b.dataset.key}"]`).dataset.value)<=1);
  updateDerived();
}
function updateDerived(){
  const s=getStats(), pv=20+s.res*5, san=20+s.con*5, en=10+s.res*2;
  $("pvMax").textContent=pv; $("sanMax").textContent=san; $("enMax").textContent=en;
  if(!$("pvCurrent").dataset.touched)$("pvCurrent").value=pv;
  if(!$("sanCurrent").dataset.touched)$("sanCurrent").value=san;
  if(!$("enCurrent").dataset.touched)$("enCurrent").value=en;
}
function renderClass(){
  const [skill,desc]=CLASS_INFO[$("class").value];
  $("classSkill").innerHTML=`<b>${skill}</b><br>${desc}`;
}
function renderInventory(){
  const used=inventory.reduce((n,x)=>n+x.slots,0);
  $("usedSlots").textContent=`${used} / 8`;
  $("inventoryHint").textContent=used>=8?"Inventário cheio. Remova um item para liberar espaço.":`Você ainda pode carregar ${8-used} espaço(s).`;
  $("inventory").innerHTML=inventory.map((item,i)=>`<div class="inventory-item"><button type="button" class="remove-item" data-remove="${i}" aria-label="Remover item">×</button><b>${escapeHtml(item.name)}</b><small>${item.slots} espaço(s)</small></div>`).join("");
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("inventory").addEventListener("click",e=>{const b=e.target.closest("[data-remove]");if(!b)return;inventory.splice(Number(b.dataset.remove),1);renderInventory();});
$("addItem").addEventListener("click",()=>{
  const name=$("itemName").value.trim(), slots=Number($("itemSlots").value);
  if(!name){toast("Digite o nome do item.");return;}
  if(inventory.reduce((n,x)=>n+x.slots,0)+slots>8){toast("O inventário não tem espaços suficientes.");return;}
  inventory.push({name,slots});$("itemName").value="";renderInventory();
});
function resetForm(){
  $("characterForm").reset(); currentId=null; inventory=[];
  ATTRS.forEach(([key])=>document.querySelector(`[data-attr="${key}"]`).dataset.value=2);
  ["pvCurrent","sanCurrent","enCurrent"].forEach(id=>delete $(id).dataset.touched);
  $("xp").value=0; renderAttributes();renderInventory();renderClass();$("pageTitle").textContent="NOVO SOBREVIVENTE";$("deleteBtn").disabled=true;renderList();
}
function formData(){
  return {
    id:currentId||uuid(),name:$("name").value.trim(),age:$("age").value,className:$("class").value,
    occupation:$("occupation").value,backstory:$("backstory").value,goal:$("goal").value,
    attributes:getStats(),pvCurrent:Number($("pvCurrent").value),sanCurrent:Number($("sanCurrent").value),
    enCurrent:Number($("enCurrent").value),condition:$("condition").value,extraSkills:$("extraSkills").value,
    xp:Number($("xp").value),inventory:[...inventory],notes:$("notes").value,updatedAt:new Date().toISOString()
  };
}
function saveCurrent(e){
  if(e)e.preventDefault();
  if(usedAttributePoints()!==6){toast("Distribua exatamente os 6 pontos extras.");return;}
  if(!$("name").value.trim()){toast("Informe o nome do personagem.");return;}
  const data=formData(), idx=characters.findIndex(c=>c.id===data.id);
  if(idx>=0)characters[idx]=data;else characters.unshift(data);
  currentId=data.id; persist(); renderList(); $("pageTitle").textContent=data.name.toUpperCase();$("deleteBtn").disabled=false;toast("Ficha salva no arquivo local.");
}
function persist(){localStorage.setItem("re2-survivors-characters",JSON.stringify(characters));}
function renderList(){
  $("characterList").innerHTML=characters.length?characters.map(c=>`<button class="character-entry ${c.id===currentId?"active":""}" data-open="${c.id}"><b>${escapeHtml(c.name)}</b><small>${escapeHtml(c.className)} • ${c.xp||0} XP</small></button>`).join(""):`<p class="hint">Nenhum sobrevivente cadastrado.</p>`;
}
function openCharacter(id){
  const c=characters.find(x=>x.id===id);if(!c)return;
  currentId=id;
  $("name").value=c.name||"";$("age").value=c.age||"";$("class").value=c.className||"Policial";
  $("occupation").value=c.occupation||"";$("backstory").value=c.backstory||"";$("goal").value=c.goal||"";
  ATTRS.forEach(([key])=>document.querySelector(`[data-attr="${key}"]`).dataset.value=c.attributes?.[key]??2);
  ["pvCurrent","sanCurrent","enCurrent"].forEach(id=>$(id).dataset.touched="1");
  $("pvCurrent").value=c.pvCurrent;$("sanCurrent").value=c.sanCurrent;$("enCurrent").value=c.enCurrent;
  $("condition").value=c.condition||"";$("extraSkills").value=c.extraSkills||"";$("xp").value=c.xp||0;
  $("notes").value=c.notes||"";inventory=Array.isArray(c.inventory)?[...c.inventory]:[];
  renderAttributes();renderClass();renderInventory();$("pageTitle").textContent=c.name.toUpperCase();$("deleteBtn").disabled=false;renderList();
}
$("characterList").addEventListener("click",e=>{const b=e.target.closest("[data-open]");if(b)openCharacter(b.dataset.open);});
$("newCharacter").addEventListener("click",resetForm);
$("class").addEventListener("change",renderClass);
$("characterForm").addEventListener("submit",saveCurrent);
$("saveBtn").addEventListener("click",saveCurrent);
$("clearBtn").addEventListener("click",()=>{if(confirm("Limpar o formulário atual? As fichas já salvas não serão apagadas."))resetForm();});
$("deleteBtn").addEventListener("click",()=>{
  if(!currentId)return;
  const c=characters.find(x=>x.id===currentId);
  if(confirm(`Excluir a ficha de ${c?.name||"este personagem"}?`)){characters=characters.filter(x=>x.id!==currentId);persist();resetForm();toast("Ficha excluída.");}
});
$("exportBtn").addEventListener("click",()=>{
  if(!currentId){toast("Salve ou abra uma ficha antes de exportar.");return;}
  const c=characters.find(x=>x.id===currentId);const blob=new Blob([JSON.stringify(c,null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`ficha-${c.name.toLowerCase().replace(/[^a-z0-9]+/g,"-")}.json`;a.click();URL.revokeObjectURL(a.href);
});
["pvCurrent","sanCurrent","enCurrent"].forEach(id=>$(id).addEventListener("input",()=>$(id).dataset.touched="1"));
buildAttributes();renderClass();renderInventory();
try{characters=JSON.parse(localStorage.getItem("re2-survivors-characters")||"[]");}catch{characters=[];}
renderList();
